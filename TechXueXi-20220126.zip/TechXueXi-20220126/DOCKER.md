**[交流群地址及说明](https://github.com/TechXueXi/TechXueXi/issues/14)**

官方网站： https://techxuexi.js.org/

#### [其他运行方式](https://github.com/TechXueXi/TechXueXi/blob/dev/%E4%BD%BF%E7%94%A8%E6%96%B9%E6%B3%95-%E6%9B%B4%E6%96%B0%E6%96%B9%E6%B3%95-%E4%B8%8B%E8%BD%BD%E6%96%B9%E5%BC%8F.md)

#### 镜像地址： https://hub.docker.com/u/techxuexi/

**重要公告**： [公告栏（国内打不开）](https://t.me/s/techxuexi_notice) || [公告栏（国内可以打开）](https://notice.techxuexi.workers.dev)

**警告：如您不熟悉，请使用源码运行的方式**

## 有疑问？

遇到问题，请试着按如下步骤解决：

1. 仔细阅读过 https://github.com/TechXueXi/TechXueXi/wiki 说明
2. 查看/搜索所有已有 issue，无论是 open 还是 close 的
3. 通过搜索引擎搜索，尝试不同的关键词 www.google.com www.baidu.com
4. 到提供的在线聊天室询问 (聊天室说明： https://github.com/TechXueXi/TechXueXi/issues/14 )
5. 提新 issue ，关注邮箱有关这个 issue 的提醒。
> \* 2021 年 9 月 25 日起 arm 和 amd 地址分开，请重新配置 docker
